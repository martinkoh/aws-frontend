let $loginFormContainer = $('#loginFormContainer');
if ($loginFormContainer.length != 0) {
    console.log('Login form detected. Binding event handling logic to form elements.');
    //If the jQuery object which represents the form element exists,
    //the following code will create a method to submit registration details
    //to server-side api when the #submitButton element fires the click event.
    $('#submitButton').on('click', function(event) {
        event.preventDefault();
        let email = $('#emailInput').val();
        let password = $('#passwordInput').val();

        const requestConfig = {
            headers : {
                'x-api-key': 'UzzKQQw4qw36EuKDOcWmyaXF8IXlB0IBaOCVZeVY'
            }
        }
        const requestBody = {
            email: email,
            password: password
        }

        axios.post('https://6ztz3uhgib.execute-api.us-east-2.amazonaws.com/prod/login', requestBody, requestConfig ).then(function(response) {
            //Inspect the object structure of the response object.
            //console.log('Inspecting the respsone object returned from the login web api');
            //console.dir(response);
            console.log("logged in")
            if (response.data.user.role == 'admin') {
                localStorage.setItem('token', response.data.user.token);
                localStorage.setItem('role_name', response.data.user.role);
                window.location.replace('admin/manage_users.html');
            }
            else {
                localStorage.setItem('token', response.data.user.token);
                localStorage.setItem('role_name', response.data.user.role);
                window.location.replace('user/manage_submission.html');
                return;
            }
        })
        .catch(function(response) {
            //Handle error
            console.log('fail login')
            console.dir(response);
            new Noty({
                type: 'error',
                layout: 'topCenter',
                theme: 'sunset',
                timeout: '6000',
                text: 'Unable to login. Check your email and password',
            }).show();

        });

        //

    });

} //End of checking for $loginFormContainer jQuery object